# imports for SQL data part
import pyodbc
from datetime import datetime, timedelta
import pandas as pd


date = datetime.today() - timedelta(days=7)  # get the date 7 days ago

date = date.strftime("%Y-%m-%d")  # convert to format yyyy-mm-dd

cnxn_str = ("Driver={SQL Server Native Client 11.0};"
            "Server=localhost;"
            "Database=TSQLV4;"
            "Trusted_Connection=yes;")
cnxn = pyodbc.connect(cnxn_str)  # initialise connection (assume we have already defined cnxn_str)


query = ("SELECT count(*) FROM HR.Employees "
         f"WHERE hireDate < '{date}'")

# execute the query and read to a dataframe in Python
data = pd.read_sql(query, cnxn)

del cnxn  # close the connection

print('I counted',data,' employees')
