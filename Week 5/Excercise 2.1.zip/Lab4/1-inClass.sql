--get a count of all orders for each employee, join two tables
select e.empid,count(o.orderid) as NumberOrders --, e.lastname, e.firstname, e.title 
from  [HR].[Employees] e inner join [Sales].[Orders] o
on e.empid = o.empid
group by e.empid--, e.lastname, e.firstname, e.title

--get all of the details of each order, join multiple tables
select e.empid, e.lastname, e.firstname, e.title, o.orderid,
o.orderdate, od.productid, od.qty
from  [HR].[Employees] e 
inner join [Sales].[Orders] o on e.empid = o.empid
inner join [Sales].[OrderDetails] od on o.orderid = od.orderid
where o.orderid = 10258

--get all of the details of each order and add the count of all orders for each row
--non correlated subquery using the previous query
select  sx.empid, sx.NumberOrders, e.lastname, e.firstname, e.title
from 
(select e.empid,count(o.orderid) as NumberOrders 
from  [HR].[Employees] e inner join [Sales].[Orders] o
on e.empid = o.empid
group by e.empid) as sx
inner join [HR].[Employees] e on sx.empid = e.empid
--10258

select e.empid, e.lastname, e.firstname, e.title, o.orderid,
o.orderdate, od.productid, od.qty, sx.NumberOrders
from  [HR].[Employees] e 
inner join [Sales].[Orders] o on e.empid = o.empid
inner join [Sales].[OrderDetails] od on o.orderid = od.orderid
inner join
(select e.empid,count(o.orderid) as NumberOrders 
from  [HR].[Employees] e inner join [Sales].[Orders] o
on e.empid = o.empid
group by e.empid) as sx on e.empid = sx.empid

where o.orderid = 10258

--correlated subquery, retrieve the most recent order date
select c.custid, c.contactname, o.orderid, o.orderdate, 
maxorderdate = (select  max(o2.orderdate) as RecentOrderDT
from [Sales].[Orders] o2 where o.custid = o2.custid
)
from [Sales].[Customers] c
inner join [Sales].[Orders] o on c.custid = o.custid
where c.custid = 1

--non correlated subquery, retrieve the most recent order date
select c.custid, c.contactname, o.orderid, o.orderdate, 
sx.RecentOrderDT
from [Sales].[Customers] c
inner join [Sales].[Orders] o on c.custid = o.custid
inner join
(select custid,  max(o2.orderdate) as RecentOrderDT
from [Sales].[Orders] o2 
group by custid
) as sx on c.custid = sx.custid
where c.custid = 1

--retrieve the  most recent order for all orders - returns a scalar value
select max(orderdate) from sales.orders

