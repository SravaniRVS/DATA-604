Backup Database TSQLV4 To DISK = 'C:\MSSQL\MSSQL14.MSSQLSERVER\MSSQL\Backup\Hw1tsql.bak'

--adds two columns 'endDate and retireDate' to Employees table
ALTER TABLE [HR].[Employees] ADD endDate Date NULL, retireDate Date NULL ;  