import sqlite3
import csv
import sys
##import requests

#add column to hold the number of recalls
#update column with number of recalls
def main():
    #Recall db file should be in same directory. The inventory and recall tables are already imported
    #function to create a table in sqllite database if it does not exist
    def create_table():
        cursor.execute('CREATE TABLE IF NOT EXISTS recallList(vin TEXT, recordID REAL, make TEXT, model TEXT, year REAL, compName TEXT, MFGName TEXT)')

    #function that creates a table of the vehicles that are recalled
    def data_entry():
        cursor.execute("INSERT INTO recallList SELECT cl.[vin], fr.[RecordID],cl.[Make],cl.[Model],fr.[Year], \
                          fr.[CompName],fr.[MFGName] \
                          FROM [FLAT_RCL] fr  inner join combinedList cl on fr.Make = cl.MAKE and \
                          cl.MODEL = fr.Model and cl.MODELYEAR = fr.Year")
        conn.commit()

    #function to retrieve the list of recall vehicles and count the total numbers in the list
    def selectData():
        cursor.execute("SELECT [vin],[recordID],[make],[model],[year],[compName],[MFGName] \
                          FROM recallList")
        recallList = cursor.fetchall()
        #print (len(recallList)) #for testing
        return recallList
        #next step is to return this list and conduct analysis, data visualization

    def selectInvList():
        cursor.execute("SELECT distinct vin FROM combinedList")
        invList = cursor.fetchall()
        return invList

    def selectBatchCount():
        cursor.execute("SELECT count(vin) FROM combinedList")
        invList = cursor.fetchall()
        return invList
    
    def selectdRecallList():
        cursor.execute("SELECT vin FROM recallList")
        recallList = cursor.fetchall()
        return recallList

    #Open a connection to database file
    conn = sqlite3.connect('recallDb.db')
    cursor = conn.cursor()

   
    
    #Run a query to see if the table with list of recalls exists and if not- calls functions to create and populate
    cursor.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='recallList'")
    varExists = cursor.fetchone()[0]
    if varExists == 0:
        create_table()
        data_entry()
                   
    #calls function to retrieve the list of recalls
    recalls = selectData()
    print( 'There are ',len(recalls),' vehicle recalls using the faster batch method')

    drecalls = selectdRecallList()

    invList = selectInvList()
    
    recallNo = 0
    #countLoop = 0

    for i in invList:
        for r in drecalls:
            #print (r)
            if i == r:
                recallNo += 1
        #countLoop = 50
        
    print('I counted',recallNo,' by comparing two records the slow way')
    
    conn.commit()
    cursor.close()
    conn.close()
main()
