-- Select statement
select * from [Production].[Products]

-- where with string select
Select 
[empid], [lastname], [firstname], [title], [titleofcourtesy], birthdate, 
year(birthdate) as birthYr,
[hiredate], [address], [city], [region]
FROM [HR].[Employees]
where region = 'WA'
order by lastname desc

-- where with operator
SELECT 
region
from HR.Employees
group by region
having count(region) > 4

-- concatenate
select [empid], [lastname], [firstname], firstname + ' ' + lastname + cast(empid as varchar) as fullname,
concat(firstname,' ',lastname,empid) as fullname2,
empid + empid as addInt,
[title], [titleofcourtesy], birthdate
from Hr.Employees

--self join
select e1.empid, e1.lastname, e1.city,e2.empid as mgrid, e2.lastname as mgrLastName, e2.city as mgrCity
from hr.Employees e1 inner join hr.Employees e2 on e1.mgrid = e2.empid

--distinct managers
select distinct e2.empid as mgrid, e2.lastname as mgrLastName, e2.city as mgrCity
from hr.Employees e1 inner join hr.Employees e2 on e1.mgrid = e2.empid

--in  true
select *
from hr.Employees e0 where mgrid in (
--select list of managers
select distinct e2.empid as mgrid
from hr.Employees e1 inner join hr.Employees e2 on e1.mgrid = e2.empid
where e2.city = 'Seattle')

--in false
select *
from hr.Employees e0 where mgrid not in (
--select list of managers
select distinct e2.empid as mgrid
from hr.Employees e1 inner join hr.Employees e2 on e1.mgrid = e2.empid
where e2.city = 'Seattle')

--exists true
select *
from hr.Employees e0 where exists (
--select list of managers
select *
from hr.Employees e1 inner join hr.Employees e2 on e1.mgrid = e2.empid
where e2.city = 'Seattle' and e0.mgrid = e2.empid)

--exists False
select *
from hr.Employees e0 where not exists (
--select list of managers
select *
from hr.Employees e1 inner join hr.Employees e2 on e1.mgrid = e2.empid
where e2.city = 'Seattle' and e0.mgrid = e2.empid)

--in NULL
select *
from hr.Employees e0 where mgrid in (
--select list of managers
select distinct e2.empid as mgrid
from hr.Employees e1 inner join hr.Employees e2 on e1.mgrid = e2.empid
/*where e2.city = 'Baltimore'*/)

--exists true
select *
from hr.Employees e0 where exists (
--select list of managers
select *
from hr.Employees e1 inner join hr.Employees e2 on e1.mgrid = e2.empid
where /*e2.city = 'Baltimore' and */e0.mgrid = e2.empid)


